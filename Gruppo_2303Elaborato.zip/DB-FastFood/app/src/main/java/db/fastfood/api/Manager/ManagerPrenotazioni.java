package db.fastfood.api.Manager;

public interface ManagerPrenotazioni {
    /**
     * Method that allow to add a new table
     */
    public void AddTable();

    /**
     * Method that allow to show all tables
     */
    public void showTable();

    /**
     * Method that allow to add a new reservation
     */
    public void showreservation();

    /**
     * Method that allow to add a new reservation
     */
    public void AddReservation();
}
