package db.fastfood.api.Manager;

public interface ManagerAddetti {
    /**
     * Method that allow to add a new employee
     */
    public void addEmployee();

    /**
     * Method that allow to show all employees
     */
    public void showEmployee();
}
