package db.fastfood.util;

public interface Util {
    
    public int getCurrentordine();

    public int getCurrentcliente();

}
