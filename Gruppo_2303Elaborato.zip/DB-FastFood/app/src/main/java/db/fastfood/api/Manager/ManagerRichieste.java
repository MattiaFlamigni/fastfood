package db.fastfood.api.Manager;

public interface ManagerRichieste {
    /**
     * Method that allow insert a new request
     */
    public void addRequest();

    /**
     * Method that allow to show and decline requests.
     * 
     */
    public void ShowDeclineRequest();
}
